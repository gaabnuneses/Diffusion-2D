##------------------------------- Bibliotecas utilizadas -------------------------------#
# Numpy - biblioteca matemática e manipulação de matrizes
import numpy as np

# MatPlotLib - criação de gráficos
import matplotlib.pyplot as plt
import imageio
# Scipy - utilizada para obter raízes e pesos de Quadratura Gauss-Legendre
from scipy.special import roots_legendre, eval_legendre
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve
from numpy.linalg import solve, norm
from scipy.interpolate import griddata
##--------------------------- Funções em outros Arquivos -------------------------------#
from loadMeshes import *
from diffusion import *
from plotmalha import *
from funcaoforma import *

# Função pra construir gif
def buildGIF():
    # Build GIF
    with imageio.get_writer('mygif.gif', mode='I') as writer:
        for i in [12,48,300,1200,2700,4800,10800]:
            filename = "Img-"+str(i)+".png"
            image = imageio.imread(filename)
            writer.append_data(image)

##------------------------------- Execução do programa -------------------------------#
# Arquivo .txt com dados da malha gerada no gmsh Versão 2 gmsh
# numel can vary in this list: [12,48,300,1200,2700,4800,10800]
val_max = []
val_min = []
nmalhas = [50,200,450,800,1800,3200,5000,8450,12800]
numel = 450

file = "Malhas/PaTurbina"+str(numel)+".txt"
file = "Malhas/PaTurbina"+str(numel)+"-Q2.txt"
# Carregamento da Malha
nodes,  bound_elem, elem = LoadMesh(file,1e-3)

#plotMalha(nodes,elem,False)
#plotContorno(nodes, bound_elem)

# Cálculo das funções de forma
nint = 3
nint_1d = 3
elemType = "Q2"
phi,dphidxi,dphideta,wk,phi_1d,dphidxi_1d,wk_1d = FuncaoForma(nint,nint_1d,elemType)

# Propriedades Físicas
gamma = 25

# Cálculo da matriz local
A,b = montar_sistema(phi,dphidxi,dphideta,wk,phi_1d,dphidxi_1d,wk_1d,nint,nint_1d,elem,bound_elem,elemType,nodes,gamma)
A = A.tocsr()
T = spsolve(A, b)
val_max.append(np.amax(T))
val_min.append(np.amin(T))

def valMaxMin():
    print(val_max)
    print(val_min)
    erro5000_max = []
    erro5000_min = []
    for i in range(len(val_max)):
        erro5000_max.append(100*np.abs(val_max[i]-val_max[len(val_max)-1])/val_max[len(val_max)-1])
        erro5000_min.append(100*np.abs(val_min[i]-val_min[len(val_min)-1])/val_min[len(val_min)-1])
    f = plt.figure()
    plt.plot(nmalhas,erro5000_max,marker='o',label="Valor Máximo")
    plt.plot(nmalhas,erro5000_min,marker='o',label="Valor Mínimo")
    plt.xlabel("Número de Elementos")
    plt.ylabel("Diferença absoluta relativa com o mais refinado [%]")
    plt.title("Refinamento de Malha para Elementos do tipo Q1")
    plt.legend()
    plt.show()

def plot_campos():
    # Mostrando o Resultado na tela
    x = []
    y = []
    for i in range(len(nodes)):
        x.append(nodes[i][1])
        y.append(nodes[i][2])

    f = plt.figure()
    f.set_figwidth(10)
    f.set_figheight(6)    
    plt.tricontourf(x,y,T,15,cmap='jet')
    plt.colorbar()

    xq = np.linspace(0,.005,30)
    yq = np.linspace(0,.003,30)
    Xq,Yq = np.meshgrid(xq,yq)

    Tq = griddata((x, y), T, (Xq, Yq))

    qx,qy=np.gradient(Tq,xq,yq)

    plt.quiver(xq,yq,-qy,-qx)
    # Ordem inversa de qx e qy por conta da alocação na matriz gerada no meshgrid

    plt.fill([.002,.002,.005,.005],[0,.001,.001,0],color='white')

    plt.show()


plot_campos()